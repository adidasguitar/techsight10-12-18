const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const AccountSchema = new Schema({
  email: {
    type: String,
    lowercase: true,
    required: true
  },
  //Startup, Investor, User, Accelerator
  account_type: {
    type: String,
    required: true
  },
  date: {
    type: Date,
    default: Date.now
  },
  password: {
    type: String,
    required: true
  }
});

module.exports = Account = mongoose.model("account", AccountSchema);
