const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const AcceleratorProfileSchema = new Schema({
  account: {
    type: Schema.Types.ObjectId,
    ref: "account"
  },
  name: {
    type: String,
    required: true
  },
  market: {
    type: String,
    required: true
  },
  state: {
    type: String,
    required: true
  },
  city: {
    type: String,
    required: true
  }
});

module.exports = AcceleratorProfile = mongoose.model(
  "accelerator_profile",
  AcceleratorProfileSchema
);
