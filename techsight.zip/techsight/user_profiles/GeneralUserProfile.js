const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const GeneralUserProfileSchema = new Schema({
  account: {
    type: Schema.Types.ObjectId,
    ref: "account"
  },
  first_name: {
    type: String,
    required: true
  },
  last_name: {
    type: String,
    required: true
  },
  age: {
    type: String,
    required: true
  },
  state: {
    type: String,
    required: true
  }
});

module.exports = GeneralUserProfile = mongoose.model(
  "generalUser_profile",
  GeneralUserProfileSchema
);
