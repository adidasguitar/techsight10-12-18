const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const StartupProfileSchema = new Schema({
  account: {
    type: Schema.Types.ObjectId,
    ref: "account"
  },
  startup_name: {
    type: String,
    required: true,
    max: 21
  },
  state: {
    type: String,
    required: true
  },
  city: {
    type: String,
    required: true
  },
  market: {
    type: String,
    required: true
  },
  team_size: {
    type: String,
    required: true
  },
  total_raised: {
    type: String,
    required: true
  },
  year_founded: {
    type: String,
    required: true
  },
  website: {
    type: String
  },
  bio: {
    type: String
  },
  profilePicture: {
    data: Buffer,
    contentType: String
  },
  social: {
    youtube: {
      type: String
    },
    twitter: {
      type: String
    },
    facebook: {
      type: String
    },
    linkedin: {
      type: String
    },
    instagram: {
      type: String
    }
  },
  founders: [
    {
      title: {
        type: String,
        required: true
      },
      first_name: {
        type: String,
        required: true
      },
      last_name: {
        type: String,
        required: true
      },
      bio: {
        type: String
      }
    }
  ],
  team: [
    {
      role: {
        type: String,
        required: true
      },
      first_name: {
        type: String,
        required: true
      },
      last_name: {
        type: String,
        required: true
      },
      bio: {
        type: String
      }
    }
  ]
});

module.exports = StartupProfile = mongoose.model(
  "startup_profile",
  StartupProfileSchema
);
