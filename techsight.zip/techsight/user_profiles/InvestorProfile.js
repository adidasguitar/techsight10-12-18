const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const InvestorProfileSchema = new Schema({
  account: {
    type: Schema.Types.ObjectId,
    ref: "account"
  },
  first_name: {
    type: String,
    required: true
  },
  last_name: {
    type: String,
    required: true
  },
  market: {
    type: String,
    required: true
  },
  state: {
    type: String,
    required: true
  },
  city: {
    type: String,
    required: true
  }
});

module.exports = InvestorProfile = mongoose.model(
  "investor_profile",
  InvestorProfileSchema
);
