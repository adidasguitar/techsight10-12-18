const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const passport = require("passport");

const account = require("./routes/api/account");
const startup = require("./routes/api/startup");
const investor = require("./routes/api/investor");
const generalUser = require("./routes/api/generalUser");

//initialize app
const app = express();

//Body parser middleware setup
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

//Database config key
const db = require("./config/keys").mongoURI;

//Use monoose to connnect to database(MongoDB)
mongoose
  .connect(
    db,
    { useNewUrlParser: true }
  )
  .then(() => console.log("Database Connected"))
  .catch(err => console.log(err));

//passport middleware
app.use(passport.initialize());

require("./config/passport")(passport);

app.use("/api/account", account);
app.use("/api/startup", startup);
app.use("/api/investor", investor);
app.use("/api/generaluser", generalUser);

//Set port number
const port = process.env.PORT || 5000;

//Tell the apps server to listen on port variable
app.listen(port, () => console.log(`Server is running on port ${port}`));
