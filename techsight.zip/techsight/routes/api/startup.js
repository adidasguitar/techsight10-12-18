const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");
const passport = require("passport");

const validateStartupInput = require("../../validation/startup");

const StartupProfile = require("../../user_profiles/StartupProfile");
const Account = require("../../user_profiles/Account");

router.get("/test", (req, res) => res.json({ msg: "Startup Profile Works" }));

// @route   GET api/startup
// @desc    Get current users startup profile
// @access  Private
router.get(
  "/",
  passport.authenticate("jwt", { session: false }),
  (req, res) => {
    const errors = {};

    StartupProfile.findOne({ account: req.user.id })
      .populate("account", ["email"])
      .then(startup => {
        if (!startup) {
          errors.nostartup = "There is no startup profile for this account";
          return res.status(404).json(errors);
        }
        res.json(startup);
      })
      .catch(err => res.status(404).json(err));
  }
);

// @route   GET api/startup/all
// @desc    Get all startups
// @access  Public
router.get("/all", (req, res) => {
  const errors = {};

  StartupProfile.find()
    .populate("account", ["email"])
    .then(startup => {
      if (!startup) {
        errors.nostartup = "There are no startups";
        return res.status(404).json(errors);
      }

      res.json(startup);
    })
    .catch(err => res.status(404).json({ profile: "There are no startups" }));
});

// @route GET api/startup/startup_name/:startup_name
// @desc GET profile by startup name
// @access Public

router.get("/startup_name/:startup_name", (req, res) => {
  const errors = {};

  StartupProfile.findOne({ startup_name: req.params.startup_name })
    .populate("account", ["email"])
    .then(startup => {
      if (!startup) {
        errors.nostartup = "There is no startup by this name";
        res.status(404).json(errors);
      }
      res.json(startup);
    })
    .catch(err => res.status(404).json(err));
});

router.post(
  "/",
  passport.authenticate("jwt", { session: false }),
  (req, res) => {
    const { errors, isValid } = validateStartupInput(req.body);

    if (!isValid) {
      return res.status(404).json(errors);
    }

    if (
      req.user.account_type === "User" ||
      req.user.account_type === "Investor"
    ) {
      console.log("Error");
      return res.status(404).json(errors);
    }

    const startupFields = {};
    startupFields.account = req.user.id;
    if (req.body.startup_name)
      startupFields.startup_name = req.body.startup_name;
    if (req.body.state) startupFields.state = req.body.state;
    if (req.body.city) startupFields.city = req.body.city;
    if (req.body.market) startupFields.market = req.body.market;
    if (req.body.team_size) startupFields.team_size = req.body.team_size;
    if (req.body.total_raised)
      startupFields.total_raised = req.body.total_raised;
    if (req.body.year_founded)
      startupFields.year_founded = req.body.year_founded;
    if (req.body.website) startupFields.website = req.body.website;
    if (req.body.bio) startupFields.bio = req.body.bio;

    // Social
    startupFields.social = {};
    if (req.body.youtube) startupFields.social.youtube = req.body.youtube;
    if (req.body.twitter) startupFields.social.twitter = req.body.twitter;
    if (req.body.facebook) startupFields.social.facebook = req.body.facebook;
    if (req.body.linkedin) startupFields.social.linkedin = req.body.linkedin;
    if (req.body.instagram) startupFields.social.instagram = req.body.instagram;

    StartupProfile.findOne({ account: req.user.id }).then(startup => {
      if (startup) {
        //update
        StartupProfile.findOneAndUpdate(
          { account: req.user.id },
          { $set: startupFields },
          { new: true }
        ).then(startup => res.json(startup));
      } else {
        //create
        StartupProfile.findOne({
          startup_name: startupFields.startup_name
        }).then(startup => {
          if (startup) {
            errors.startup_name = "That name is already taken";
            res.status(400).json(errors);
          }

          //Save Profile
          new StartupProfile(startupFields)
            .save()
            .then(startup => res.json(startup));
        });
      }
    });
  }
);

router.delete(
  "/",
  passport.authenticate("jwt", { session: false }),
  (req, res) => {
    StartupProfile.findOneAndRemove({ account: req.user.id }).then(() => {
      Account.findOneAndRemove({ _id: req.user.id }).then(() =>
        res.json({ success: true })
      );
    });
  }
);

router.post(
  "/",
  passport.authenticate("jwt", { session: false }),
  (req, res) => {
    if (!isValid) {
      return res.status(404).json(errors);
    }

    if (
      req.user.account_type === "User" ||
      req.user.account_type === "Investor"
    ) {
      console.log("Error");
      return res.status(404).json(errors);
    }

    const startupFields = {};
    startupFields.account = req.user.id;
    if (req.body.startup_name)
      startupFields.startup_name = req.body.startup_name;
    if (req.body.state) startupFields.state = req.body.state;
    if (req.body.city) startupFields.city = req.body.city;
    if (req.body.market) startupFields.market = req.body.market;
    if (req.body.team_size) startupFields.team_size = req.body.team_size;
    if (req.body.total_raised)
      startupFields.total_raised = req.body.total_raised;
    if (req.body.year_founded)
      startupFields.year_founded = req.body.year_founded;
    if (req.body.website) startupFields.website = req.body.website;
    if (req.body.bio) startupFields.bio = req.body.bio;
    if (req.body.profilePicture)
      startupFields.profilePicture = req.body.profilePicture;

    // Social
    startupFields.social = {};
    if (req.body.youtube) startupFields.social.youtube = req.body.youtube;
    if (req.body.twitter) startupFields.social.twitter = req.body.twitter;
    if (req.body.facebook) startupFields.social.facebook = req.body.facebook;
    if (req.body.linkedin) startupFields.social.linkedin = req.body.linkedin;
    if (req.body.instagram) startupFields.social.instagram = req.body.instagram;

    StartupProfile.findOne({ account: req.user.id }).then(startup => {
      if (startup) {
        //update
        StartupProfile.findOneAndUpdate(
          { account: req.user.id },
          { $set: startupFields },
          { new: true }
        ).then(startup => res.json(startup));
      } else {
        //create
        StartupProfile.findOne({
          startup_name: startupFields.startup_name
        }).then(startup => {
          if (startup) {
            errors.startup_name = "That name is already taken";
            res.status(400).json(errors);
          }

          //Save Profile
          new StartupProfile(startupFields)
            .save()
            .then(startup => res.json(startup));
        });
      }
    });
  }
);
module.exports = router;
