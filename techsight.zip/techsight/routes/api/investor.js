const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");
const passport = require("passport");

const validateInvestorInput = require("../../validation/investor");

const InvestorProfile = require("../../user_profiles/InvestorProfile");
const Account = require("../../user_profiles/Account");

router.get("/test", (req, res) => res.json({ msg: "Investor Profile Works" }));

// @route   GET api/investor
// @desc    Get current users investor profile
// @access  Private
router.get(
  "/",
  passport.authenticate("jwt", { session: false }),
  (req, res) => {
    const errors = {};

    InvestorProfile.findOne({ account: req.user.id })
      .populate("account", ["email"])
      .then(investor => {
        if (!investor) {
          errors.noinvestor = "There is no investor for this user";
          return res.status(404).json(errors);
        }
        res.json(investor);
      })
      .catch(err => res.status(404).json(err));
  }
);

router.post(
  "/",
  passport.authenticate("jwt", { session: false }),
  (req, res) => {
    const { errors, isValid } = validateInvestorInput(req.body);

    if (!isValid) {
      return res.status(404).json(errors);
    }
    if (
      req.user.account_type === "User" ||
      req.user.account_type === "Startup"
    ) {
      console.log("Error");
      return res.status(404).json(errors);
    }

    const investorFields = {};
    investorFields.account = req.user.id;
    if (req.body.first_name) investorFields.first_name = req.body.first_name;
    if (req.body.last_name) investorFields.last_name = req.body.last_name;
    if (req.body.market) investorFields.market = req.body.market;
    if (req.body.state) investorFields.state = req.body.state;
    if (req.body.city) investorFields.city = req.body.city;

    // Social
    investorFields.social = {};
    if (req.body.youtube) investorFields.social.youtube = req.body.youtube;
    if (req.body.twitter) investorFields.social.twitter = req.body.twitter;
    if (req.body.facebook) investorFields.social.facebook = req.body.facebook;
    if (req.body.linkedin) investorFields.social.linkedin = req.body.linkedin;
    if (req.body.instagram)
      investorFields.social.instagram = req.body.instagram;

    InvestorProfile.findOne({ account: req.user.id }).then(investor => {
      if (investor) {
        //update
        InvestorProfile.findOneAndUpdate(
          { account: req.user.id },
          { $set: investorFields },
          { new: true }
        ).then(investor => res.json(investor));
      } else {
        //Create Save Profile
        new InvestorProfile(investorFields)
          .save()
          .then(investor => res.json(investor));
      }
    });
  }
);

module.exports = router;
