const express = require("express");
const router = express.Router();

const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const keys = require("../../config/keys");
const passport = require("passport");

const validateRegisterInput = require("../../validation/register");
const validateLoginInput = require("../../validation/login");

const Account = require("../../user_profiles/Account");

router.get("/test", (req, res) => res.json({ msg: "Account Works" }));

router.post("/register", (req, res) => {
  const { errors, isValid } = validateRegisterInput(req.body);

  if (!isValid) {
    return res.status(400).json(errors);
  }

  Account.findOne({ email: req.body.email }).then(account => {
    if (account) {
      errors.email = "Email already exists";
      return res.status(400).json(errors);
    } else {
      const newAccount = new Account({
        email: req.body.email,
        account_type: req.body.account_type,
        password: req.body.password
      });

      bcrypt.genSalt(10, (err, salt) => {
        bcrypt.hash(newAccount.password, salt, (err, hash) => {
          if (err) throw err;
          newAccount.password = hash;
          newAccount
            .save()
            .then(account => res.json(account))
            .catch(err => console.log(err));
        });
      });
    }
  });
});

// @route   GET api/account/login
// @desc    Login Account / Returning JWT Token
// @access  Public
router.post("/login", (req, res) => {
  const { errors, isValid } = validateLoginInput(req.body);

  // Check Validation
  if (!isValid) {
    return res.status(400).json(errors);
  }

  const email = req.body.email;
  const password = req.body.password;

  // Find account by email
  Account.findOne({ email }).then(account => {
    // Check for account
    if (!account) {
      errors.email = "Account not found";
      return res.status(404).json(errors);
    }

    // Check Password
    bcrypt.compare(password, account.password).then(isMatch => {
      if (isMatch) {
        // User Matched
        const payload = {
          id: account.id,
          email: account.email,
          account_type: account.account_type
        }; // Create JWT Payload

        // Sign Token
        jwt.sign(
          payload,
          keys.secretOrKey,
          { expiresIn: 36000 },
          (err, token) => {
            res.json({
              success: true,
              token: "Bearer " + token
            });
          }
        );
      } else {
        errors.password = "Password incorrect";
        return res.status(400).json(errors);
      }
    });
  });
});

// @route   GET api/account/current
// @desc    Return current account
// @access  Private
router.get(
  "/current",
  passport.authenticate("jwt", { session: false }),
  (req, res) => {
    res.json({
      id: req.user.id,
      email: req.user.email,
      account_type: req.user.account_type
    });
  }
);

// @route   GET api/account/accounttype
// @desc    Return current account type
// @access  Private
router.get(
  "/accounttype",
  passport.authenticate("jwt", { session: false }),
  (req, res) => {
    res.json({
      account_type: req.user.account_type
    });
  }
);

module.exports = router;
