const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");
const passport = require("passport");

const validateGeneralUserInput = require("../../validation/generalUser");

const GeneralUserProfile = require("../../user_profiles/GeneralUserProfile");
const Account = require("../../user_profiles/Account");

router.get("/test", (req, res) =>
  res.json({ msg: "General User Profile Works" })
);

// @route   GET api/generalUser
// @desc    Get current users generalUser profile
// @access  Private
router.get(
  "/",
  passport.authenticate("jwt", { session: false }),
  (req, res) => {
    const errors = {};

    GeneralUserProfile.findOne({ account: req.user.id })
      .populate("account", ["email"])
      .then(generalUser => {
        if (!generalUser) {
          errors.nogeneralUser = "There is no general user for this user";
          return res.status(404).json(errors);
        }
        res.json(generalUser);
      })
      .catch(err => res.status(404).json(err));
  }
);

router.post(
  "/",
  passport.authenticate("jwt", { session: false }),
  (req, res) => {
    const { errors, isValid } = validateGeneralUserInput(req.body);

    if (!isValid) {
      return res.status(404).json(errors);
    }
    if (
      req.user.account_type === "Investor" ||
      req.user.account_type === "Startup"
    ) {
      console.log("Error");
      return res.status(404).json(errors);
    }

    const generalUserFields = {};
    generalUserFields.account = req.user.id;
    if (req.body.first_name) generalUserFields.first_name = req.body.first_name;
    if (req.body.last_name) generalUserFields.last_name = req.body.last_name;
    if (req.body.age) generalUserFields.age = req.body.age;
    if (req.body.state) generalUserFields.state = req.body.state;

    // Social
    generalUserFields.social = {};
    if (req.body.youtube) generalUserFields.social.youtube = req.body.youtube;
    if (req.body.twitter) generalUserFields.social.twitter = req.body.twitter;
    if (req.body.facebook)
      generalUserFields.social.facebook = req.body.facebook;
    if (req.body.linkedin)
      generalUserFields.social.linkedin = req.body.linkedin;
    if (req.body.instagram)
      generalUserFields.social.instagram = req.body.instagram;

    GeneralUserProfile.findOne({ account: req.user.id }).then(generalUser => {
      if (generalUser) {
        //update
        GeneralUserProfile.findOneAndUpdate(
          { account: req.user.id },
          { $set: generalUserFields },
          { new: true }
        ).then(generalUser => res.json(generalUser));
      } else {
        //Create Save Profile
        new GeneralUserProfile(generalUserFields)
          .save()
          .then(generalUser => res.json(generalUser));
      }
    });
  }
);

module.exports = router;
