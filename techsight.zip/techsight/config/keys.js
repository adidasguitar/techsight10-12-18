module.exports = {
  mongoURI:
    "mongodb://DanielPatrickHug:AdidasGuitar1@ds149742.mlab.com:49742/techsight-master",
  secretOrKey: "adidasguitar"
};
