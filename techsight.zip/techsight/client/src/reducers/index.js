import { combineReducers } from "redux";
import authReducer from "./authReducer";
import errorReducer from "./errorReducer";
import startupReducer from "./startupReducer";
import investorReducer from "./investorReducer";
import generalUserReducer from "./generalUserReducer";

export default combineReducers({
  auth: authReducer,
  startup: startupReducer,
  investor: investorReducer,
  generalUser: generalUserReducer,
  errors: errorReducer
});
