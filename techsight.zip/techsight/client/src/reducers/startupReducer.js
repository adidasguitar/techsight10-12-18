import { GET_STARTUP, GET_STARTUPS, STARTUP_LOADING } from "../actions/types";

const initialState = {
  startup: null,
  startups: null,
  loading: false
};

export default function(state = initialState, action) {
  switch (action.type) {
    case STARTUP_LOADING:
      return {
        ...state,
        loading: true
      };
    case GET_STARTUP:
      return {
        ...state,
        startup: action.payload,
        loading: false
      };
    case GET_STARTUPS:
      return {
        ...state,
        startups: action.payload,
        loading: false
      };
    default:
      return state;
  }
}
