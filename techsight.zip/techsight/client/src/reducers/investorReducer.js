import {
  GET_INVESTOR,
  GET_INVESTORS,
  INVESTORS_LOADING
} from "../actions/types";

const initialState = {
  investor: null,
  investors: null,
  loading: false
};

export default function(state = initialState, action) {
  switch (action.type) {
    case INVESTORS_LOADING:
      return {
        ...state,
        loading: true
      };
    case GET_INVESTOR:
      return {
        ...state,
        investor: action.payload,
        loading: false
      };
    case GET_INVESTORS:
      return {
        ...state,
        investors: action.payload,
        loading: false
      };
    default:
      return state;
  }
}
