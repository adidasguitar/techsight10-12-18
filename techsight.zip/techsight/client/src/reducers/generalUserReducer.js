import {
  GET_GENERALUSER,
  GET_GENERALUSERS,
  GET_GENERALUSERS_LOADING
} from "../actions/types";

const initialState = {
  generalUser: null,
  generalUsers: null,
  loading: false
};

export default function(state = initialState, action) {
  switch (action.type) {
    case GET_GENERALUSERS_LOADING:
      return {
        ...state,
        loading: true
      };
    case GET_GENERALUSER:
      return {
        ...state,
        generalUser: action.payload,
        loading: false
      };
    case GET_GENERALUSERS:
      return {
        ...state,
        generalUser: action.payload,
        loading: false
      };
    default:
      return state;
  }
}
