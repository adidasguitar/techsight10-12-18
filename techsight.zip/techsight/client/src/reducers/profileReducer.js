import { CLEAR_CURRENT_PROFILE } from "../actions/types";

const initialState = {
  startup: null,
  investor: null,
  generalUser: null
};

export default function(state = initialState, action) {
  switch (action.type) {
    case CLEAR_CURRENT_PROFILE:
      return {
        ...state,
        startup: null,
        investor: null,
        general_user: null
      };
    default:
      return state;
  }
}
