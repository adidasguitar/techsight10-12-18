import React, { Component } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import PropTypes from "prop-types";
import TextFieldGroup from "../common/TextFieldGroup";
import InputGroup from "../common/InputGroup";
import { createStartup } from "../../actions/startupActions";

class CreateStartup extends Component {
  constructor(props) {
    super(props);
    this.state = {
      displaySocialInputs: false,
      startup_name: "",
      state: "",
      city: "",
      market: "",
      team_size: "",
      total_raised: "",
      year_founded: "",
      website: "",
      bio: "",
      twitter: "",
      facebook: "",
      linkedin: "",
      youtube: "",
      instagram: "",
      errors: {}
    };

    this.onChange = this.onChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.errors) {
      this.setState({ errors: nextProps.errors });
    }
  }

  onSubmit(e) {
    e.preventDefault();

    const startupData = {
      startup_name: this.state.startup_name,
      state: this.state.state,
      city: this.state.city,
      market: this.state.market,
      team_size: this.state.team_size,
      total_raised: this.state.total_raised,
      year_founded: this.state.year_founded,
      website: this.state.website,
      bio: this.state.bio,
      twitter: this.state.twitter,
      facebook: this.state.facebook,
      linkedin: this.state.linkedin,
      youtube: this.state.youtube,
      instagram: this.state.instagram
    };

    this.props.createStartup(startupData, this.props.history);
  }

  onChange(e) {
    this.setState({ [e.target.name]: e.target.value });
  }

  render() {
    const { errors, displaySocialInputs } = this.state;

    let socialInputs;

    if (displaySocialInputs) {
      socialInputs = (
        <div>
          <InputGroup
            placeholder="Twitter Profile URL"
            name="twitter"
            icon="fab fa-twitter"
            value={this.state.twitter}
            onChange={this.onChange}
            error={errors.twitter}
          />

          <InputGroup
            placeholder="Facebook Page URL"
            name="facebook"
            icon="fab fa-facebook"
            value={this.state.facebook}
            onChange={this.onChange}
            error={errors.facebook}
          />

          <InputGroup
            placeholder="Linkedin Profile URL"
            name="linkedin"
            icon="fab fa-linkedin"
            value={this.state.linkedin}
            onChange={this.onChange}
            error={errors.linkedin}
          />

          <InputGroup
            placeholder="YouTube Channel URL"
            name="youtube"
            icon="fab fa-youtube"
            value={this.state.youtube}
            onChange={this.onChange}
            error={errors.youtube}
          />

          <InputGroup
            placeholder="Instagram Page URL"
            name="instagram"
            icon="fab fa-instagram"
            value={this.state.instagram}
            onChange={this.onChange}
            error={errors.instagram}
          />
        </div>
      );
    }

    // Select options for market

    return (
      <div className="create-startup">
        <div className="container">
          <div className="row">
            <div className="col-md-8 m-auto">
              <h1 className="display-4 text-center">Create Your Startup</h1>
              <p className="lead text-center">
                Lets get some information to make your startup stand out
              </p>
              <small className="d-block pb-3">* = required fields</small>
              <form onSubmit={this.onSubmit}>
                <TextFieldGroup
                  placeholder="* Startup name"
                  name="startup_name"
                  value={this.state.startup_name}
                  onChange={this.onChange}
                  error={errors.startup_name}
                  info="A unique name for your startup URL. Your full name, company name, nickname"
                />
                <TextFieldGroup
                  placeholder="* State"
                  name="state"
                  value={this.state.state}
                  onChange={this.onChange}
                  error={errors.state}
                  info="A unique name for your startup URL. Your full name, company name, nickname"
                />
                <TextFieldGroup
                  placeholder="* City"
                  name="city"
                  value={this.state.city}
                  onChange={this.onChange}
                  error={errors.city}
                  info="A unique name for your startup URL. Your full name, company name, nickname"
                />
                <TextFieldGroup
                  placeholder="* Market"
                  name="market"
                  value={this.state.market}
                  onChange={this.onChange}
                  error={errors.market}
                  info="A unique name for your startup URL. Your full name, company name, nickname"
                />
                <TextFieldGroup
                  placeholder="* Team Size"
                  name="team_size"
                  value={this.state.team_size}
                  onChange={this.onChange}
                  error={errors.team_size}
                  info="A unique name for your startup URL. Your full name, company name, nickname"
                />
                <TextFieldGroup
                  placeholder="* Total Raised"
                  name="total_raised"
                  value={this.state.total_raised}
                  onChange={this.onChange}
                  error={errors.total_raised}
                  info="A unique name for your startup URL. Your full name, company name, nickname"
                />
                <TextFieldGroup
                  placeholder="* Year Founded"
                  name="year_founded"
                  value={this.state.year_founded}
                  onChange={this.onChange}
                  error={errors.year_founded}
                  info="A unique name for your startup URL. Your full name, company name, nickname"
                />
                <TextFieldGroup
                  placeholder="* Website"
                  name="website"
                  value={this.state.website}
                  onChange={this.onChange}
                  error={errors.website}
                  info="A unique name for your startup URL. Your full name, company name, nickname"
                />
                <TextFieldGroup
                  placeholder="* Bio"
                  name="bio"
                  value={this.state.bio}
                  onChange={this.onChange}
                  error={errors.bio}
                  info="A unique name for your startup URL. Your full name, company name, nickname"
                />
                <div className="mb-3">
                  <button
                    type="button"
                    onClick={() => {
                      this.setState(prevState => ({
                        displaySocialInputs: !prevState.displaySocialInputs
                      }));
                    }}
                    className="btn btn-light"
                  >
                    Add Social Network Links
                  </button>
                  <span className="text-muted">Optional</span>
                </div>
                {socialInputs}
                <input
                  type="submit"
                  value="Submit"
                  className="btn btn-info btn-block mt-4"
                />
              </form>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

CreateStartup.propTypes = {
  startup: PropTypes.object.isRequired,
  errors: PropTypes.object.isRequired
};

const mapStateToProps = state => ({
  startup: state.startup,
  errors: state.errors
});

export default connect(
  mapStateToProps,
  { createStartup }
)(withRouter(CreateStartup));
