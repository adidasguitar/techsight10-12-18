import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Link } from "react-router-dom";

import { getCurrentInvestor } from "../../actions/investorActions";

class InvestorDashboard extends Component {
  componentDidMount() {
    this.props.getCurrentInvestor();
  }

  render() {
    const { investor } = this.props.investor;

    let investorContent;
    if (investor === null) {
      investorContent = <div> loading</div>;
    } else {
      if (Object.keys(investor).length > 0) {
        investorContent = (
          <div>
            <p className="lead text-muted">
              Welcome {investor.first_name} {investor.last_name}
            </p>
          </div>
        );
      } else {
        investorContent = (
          <div>
            <p>You have not set up your profile yet</p>
            <Link to="/create-investor" className="btn btn-lg btn-info">
              Create Investor
            </Link>
          </div>
        );
      }
    }
    return <div> {investorContent}</div>;
  }
}

InvestorDashboard.propTypes = {
  getCurrentInvestor: PropTypes.func.isRequired,
  auth: PropTypes.object.isRequired,
  investor: PropTypes.object.isRequired
};

const mapStateToProps = state => ({
  auth: state.auth,
  investor: state.investor
});

export default connect(
  mapStateToProps,
  { getCurrentInvestor }
)(InvestorDashboard);
