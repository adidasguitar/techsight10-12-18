import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";

import Startup from "./StartupDashboard";
import Investor from "./InvestorDashboard";
import GeneralUser from "./GeneralUserDashboard";

class Dashboard extends Component {
  render() {
    const { account } = this.props.auth;

    let dashboardContent;

    if (account.account_type === "Investor") {
      dashboardContent = <Investor />;
    } else if (account.account_type === "User") {
      dashboardContent = <GeneralUser />;
    } else if (account.account_type === "Startup") {
      dashboardContent = <Startup />;
    }

    return (
      <div className="dashboard">
        <div className="container">
          <div className="row">
            <div classame="col-md-12">
              <h1 className="display-4">DashBoard</h1>
              {dashboardContent}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

Dashboard.propTypes = {
  auth: PropTypes.object.isRequired
};

const mapStateToProps = state => ({
  auth: state.auth
});

export default connect(mapStateToProps)(Dashboard);
