import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Link } from "react-router-dom";

import { getCurrentGeneralUser } from "../../actions/generalUserActions";

class GeneralUserDashboard extends Component {
  componentDidMount() {
    this.props.getCurrentGeneralUser();
  }

  render() {
    const { generalUser } = this.props.generalUser;

    let generalUserContent;
    if (generalUser === null) {
      generalUserContent = <div> nathan</div>;
    } else {
      if (Object.keys(generalUser).length > 0) {
        generalUserContent = (
          <div>
            <p className="lead text-muted">
              Welcome {generalUser.first_name} {generalUser.last_name}
            </p>
          </div>
        );
      } else {
        generalUserContent = (
          <div>
            <p>You have not set up your profile yet</p>
            <Link to="/create-generaluser" className="btn btn-lg btn-info">
              Create General User
            </Link>
          </div>
        );
      }
    }
    return <div> {generalUserContent}</div>;
  }
}

GeneralUserDashboard.propTypes = {
  getCurrentGeneralUser: PropTypes.func.isRequired,
  auth: PropTypes.object.isRequired,
  generalUser: PropTypes.object.isRequired
};

const mapStateToProps = state => ({
  auth: state.auth,
  generalUser: state.generalUser
});

export default connect(
  mapStateToProps,
  { getCurrentGeneralUser }
)(GeneralUserDashboard);
