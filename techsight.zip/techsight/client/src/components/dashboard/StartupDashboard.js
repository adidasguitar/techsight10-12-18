import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Link } from "react-router-dom";

import { getCurrentStartup } from "../../actions/startupActions";

class StartupDashboard extends Component {
  componentDidMount() {
    this.props.getCurrentStartup();
  }

  render() {
    const { startup } = this.props.startup;

    let startupContent;
    if (startup === null) {
      startupContent = <div> Loading</div>;
    } else {
      if (Object.keys(startup).length > 0) {
        startupContent = (
          <div>
            <p className="lead text-muted">Welcome {startup.startup_name}</p>
          </div>
        );
      } else {
        startupContent = (
          <div>
            <p>You have not set up your profile yet</p>
            <Link to="/create-startup" className="btn btn-lg btn-info">
              Create Startup
            </Link>
          </div>
        );
      }
    }
    return <div>{startupContent}</div>;
  }
}

StartupDashboard.propTypes = {
  getCurrentStartup: PropTypes.func.isRequired,
  auth: PropTypes.object.isRequired,
  startup: PropTypes.object.isRequired
};

const mapStateToProps = state => ({
  auth: state.auth,
  startup: state.startup
});

export default connect(
  mapStateToProps,
  { getCurrentStartup }
)(StartupDashboard);
