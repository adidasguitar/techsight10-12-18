import React, { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import StartupItem from "./StartupItem";
import { getStartupProfiles } from "../../actions/startupActions";

class Startups extends Component {
  componentDidMount() {
    this.props.getStartupProfiles();
  }

  render() {
    const { startups, loading } = this.props.startup;
    let startupItems;

    if (startups === null || loading) {
      startupItems = <h4>Loading ...</h4>;
    } else {
      if (startups.length > 0) {
        startupItems = startups.map(startup => (
          <StartupItem key={startup._id} startup={startup} />
        ));
      } else {
        startupItems = <h4>No Startups Found...</h4>;
      }
    }

    return (
      <body className="HolyGrail-profiles">
        <div className="HolyGrail-body-profiles">
          <main className="HolyGrail-content-profiles">{startupItems}</main>
          <nav className="HolyGrail-nav-profiles" />
          <aside className="HolyGrail-ads-profiles" />
        </div>
      </body>
    );
  }
}

Startups.proptypes = {
  getStartupProfiles: PropTypes.func.isRequired,
  startup: PropTypes.object.isRequired
};

const mapStateToProps = state => ({
  startup: state.startup
});

export default connect(
  mapStateToProps,
  { getStartupProfiles }
)(Startups);
