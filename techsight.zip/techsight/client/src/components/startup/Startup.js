import React, { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import { getStartupByName } from "../../actions/startupActions";

class Startup extends Component {
  componentDidMount() {
    if (this.props.match.params.startup_name) {
      this.props.getStartupByName(this.props.match.params.startup_name);
    }
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.startup.startup === null && this.props.startup.loading) {
      this.props.history.push("/not-found");
    }
  }

  render() {
    const { startup, loading } = this.props.startup;
    let startupContent;

    if (startup === null || loading) {
      startupContent = <h4>Loading ...</h4>;
    } else {
      startupContent = (
        <div>
          <div className="row">
            <div className="col-md-6">
              <Link to="/startups" className="btn btn-light mb-3 float-left">
                Back To Profiles
              </Link>
            </div>
            <div className="col-md-6" />
          </div>
          <div />
          <br />
        </div>
      );
    }

    return (
      <body className="HolyGrail-profile">
        <div className="HolyGrail-body-profile">
          <main className="HolyGrail-content-profile">{startupContent}</main>
          <nav className="HolyGrail-nav-profile" />
          <aside className="HolyGrail-ads-profile" />
        </div>
      </body>
    );
  }
}

Startup.propTypes = {
  getStartupByName: PropTypes.func.isRequired,
  startup: PropTypes.object.isRequired
};

const mapStateToProps = state => ({
  startup: state.startup
});

export default connect(
  mapStateToProps,
  { getStartupByName }
)(Startup);
