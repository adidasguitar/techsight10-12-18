import { CLEAR_CURRENT_PROFILE } from "./types";

export const clearCurrentProfile = () => {
  return {
    type: CLEAR_CURRENT_PROFILE
  };
};
