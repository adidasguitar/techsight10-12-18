import axios from "axios";
import setAuthToken from "../utils/setAuthToken";
import jwt_decode from "jwt-decode";

import { GET_ERRORS, SET_CURRENT_USER } from "./types";

export const registerAccount = (accountData, history) => dispatch => {
  axios
    .post("/api/account/register", accountData)
    .then(res => history.push("/login"))
    .catch(err =>
      dispatch({
        type: GET_ERRORS,
        payload: err.response.data
      })
    );
};

//Login - Get User Token
export const loginAccount = userData => dispatch => {
  axios.post("/api/account/login", userData).then(res => {
    //Save to local storage
    const { token } = res.data;
    //Set token to local storage
    localStorage.setItem("jwtToken", token);
    //Set token to auth header
    setAuthToken(token);
    //Decode Token to get user userData
    const decoded = jwt_decode(token);
    //Set current user
    dispatch(setCurrentUser(decoded));
  });
};

export const setCurrentUser = decoded => {
  return {
    type: SET_CURRENT_USER,
    payload: decoded
  };
};

export const logoutAccount = () => dispatch => {
  //Remove token from local storage
  localStorage.removeItem("jwtToken");
  //Remove auth header
  setAuthToken(false);
  //Set current user
  dispatch(setCurrentUser({}));
};
