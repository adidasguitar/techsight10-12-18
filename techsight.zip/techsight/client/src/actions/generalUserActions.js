import axios from "axios";
import { GET_GENERALUSER, GET_ERRORS } from "./types";

export const getCurrentGeneralUser = () => dispatch => {
  axios
    .get("/api/generaluser")
    .then(res =>
      dispatch({
        type: GET_GENERALUSER,
        payload: res.data
      })
    )
    .catch(err =>
      dispatch({
        type: GET_GENERALUSER,
        payload: {}
      })
    );
};

export const createGeneralUser = (generalUserData, history) => dispatch => {
  axios
    .post("/api/generaluser", generalUserData)
    .then(res => history.push("/dashboard"))
    .catch(err =>
      dispatch({
        type: GET_ERRORS,
        payload: err.response.data
      })
    );
};
