import axios from "axios";
import {
  GET_STARTUP,
  GET_ERRORS,
  STARTUP_LOADING,
  GET_STARTUPS
} from "./types";

export const getCurrentStartup = () => dispatch => {
  dispatch(setStartupProfileLoading());
  axios
    .get("/api/startup")
    .then(res =>
      dispatch({
        type: GET_STARTUP,
        payload: res.data
      })
    )
    .catch(err =>
      dispatch({
        type: GET_STARTUP,
        payload: {}
      })
    );
};
export const createStartup = (startupData, history) => dispatch => {
  axios
    .post("/api/startup", startupData)
    .then(res => history.push("/dashboard"))
    .catch(err =>
      dispatch({
        type: GET_ERRORS,
        payload: err.response.data
      })
    );
};

export const getStartupByName = startup_name => dispatch => {
  dispatch(setStartupProfileLoading());
  axios
    .get(`/api/startup/startup_name/${startup_name}`)
    .then(res =>
      dispatch({
        type: GET_STARTUP,
        payload: res.data
      })
    )
    .catch(err =>
      dispatch({
        type: GET_STARTUP,
        payload: null
      })
    );
};

export const getStartupProfiles = () => dispatch => {
  dispatch(setStartupProfileLoading());
  axios
    .get("/api/startup/all")
    .then(res =>
      dispatch({
        type: GET_STARTUPS,
        payload: res.data
      })
    )
    .catch(err =>
      dispatch({
        type: GET_ERRORS,
        payload: null
      })
    );
};

export const setStartupProfileLoading = () => {
  return {
    type: STARTUP_LOADING
  };
};
