import axios from "axios";
import { GET_INVESTOR, GET_ERRORS } from "./types";

export const getCurrentInvestor = () => dispatch => {
  axios
    .get("/api/investor")
    .then(res =>
      dispatch({
        type: GET_INVESTOR,
        payload: res.data
      })
    )
    .catch(err =>
      dispatch({
        type: GET_INVESTOR,
        payload: {}
      })
    );
};

export const createInvestor = (investorData, history) => dispatch => {
  axios
    .post("/api/investor", investorData)
    .then(res => history.push("/dashboard"))
    .catch(err =>
      dispatch({
        type: GET_ERRORS,
        payload: err.response.data
      })
    );
};
