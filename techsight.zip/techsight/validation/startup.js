const Validator = require("validator");
const isEmpty = require("./is-empty");

module.exports = function validateStartupInput(data) {
  let errors = {};

  data.startup_name = !isEmpty(data.startup_name) ? data.startup_name : "";
  data.state = !isEmpty(data.state) ? data.state : "";
  data.city = !isEmpty(data.city) ? data.city : "";
  data.market = !isEmpty(data.market) ? data.market : "";
  data.team_size = !isEmpty(data.team_size) ? data.team_size : "";
  data.total_raised = !isEmpty(data.total_raised) ? data.total_raised : "";
  data.year_founded = !isEmpty(data.year_founded) ? data.year_founded : "";

  if (!Validator.isLength(data.startup_name, { min: 2, max: 20 })) {
    errors.startup_name = "Startup name needs to between 2 and 20 characters";
  }

  if (Validator.isEmpty(data.startup_name)) {
    errors.startup_name = "Startup name is required";
  }
  if (Validator.isEmpty(data.state)) {
    errors.state = "State is required";
  }
  if (Validator.isEmpty(data.city)) {
    errors.city = "City is required";
  }
  if (Validator.isEmpty(data.market)) {
    errors.market = "Market field is required";
  }
  if (Validator.isEmpty(data.team_size)) {
    errors.team_size = "Team size is required";
  }
  if (Validator.isEmpty(data.total_raised)) {
    errors.total_raised = "Total raised is required";
  }
  if (Validator.isEmpty(data.year_founded)) {
    errors.year_founded = "Year founded is required";
  }

  if (!isEmpty(data.website)) {
    if (!Validator.isURL(data.website)) {
      errors.website = "Not a valid URL";
    }
  }

  if (!isEmpty(data.youtube)) {
    if (!Validator.isURL(data.youtube)) {
      errors.youtube = "Not a valid URL";
    }
  }

  if (!isEmpty(data.twitter)) {
    if (!Validator.isURL(data.twitter)) {
      errors.twitter = "Not a valid URL";
    }
  }

  if (!isEmpty(data.facebook)) {
    if (!Validator.isURL(data.facebook)) {
      errors.facebook = "Not a valid URL";
    }
  }

  if (!isEmpty(data.linkedin)) {
    if (!Validator.isURL(data.linkedin)) {
      errors.linkedin = "Not a valid URL";
    }
  }

  if (!isEmpty(data.instagram)) {
    if (!Validator.isURL(data.instagram)) {
      errors.instagram = "Not a valid URL";
    }
  }

  return {
    errors,
    isValid: isEmpty(errors)
  };
};
